package Work2;

public class Person {
    protected String name;
    protected int id;

    public Person() {
    }

    public Person(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void introduce() {
        System.out.println("ID:" + id + " 姓名:" + name);
    }
}
