package Work2;

public class Student extends Person {
    private int gardeLevel;

    public Student() {
    }

    public Student(String name, int id, int gardeLevel) {
        super(name, id);
        this.gardeLevel = gardeLevel;
    }

    public void introduce() {
        System.out.println("ID:" + id + " 姓名:" + name + " 所属年级" + gardeLevel);
    }
}
