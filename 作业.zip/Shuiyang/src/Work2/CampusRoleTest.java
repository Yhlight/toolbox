package Work2;

public class CampusRoleTest {
    public static void main(String[] args) {
        Person p1 = new Person("睡扬", 1001);
        Student stu = new Student("除之鸟", 1002, 3);
        Teacher t1 = new Teacher("荧火light", 1003, "魔法工艺");
        p1.introduce();
        stu.introduce();
        t1.introduce();
    }
}