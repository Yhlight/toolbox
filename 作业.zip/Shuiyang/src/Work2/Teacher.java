package Work2;

public class Teacher extends Person {
    private String subject;

    public Teacher() {
    }

    public Teacher(String name, int id, String subject) {
        super(name, id);
        this.subject = subject;
    }

    public void introduce() {
        System.out.println("ID:" + id + " 姓名:" + name + " 所授科目" + subject);
    }
}
