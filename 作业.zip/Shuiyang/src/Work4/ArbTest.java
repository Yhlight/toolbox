package Work4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ArbTest {
    public static void main(String[] args) {

        String inputFilePath = "D:\\yhprogram\\java project\\ArbitraryTest\\Shuiyang\\src\\Work4\\a.txt";
        String outputFilePath = "D:\\yhprogram\\java project\\ArbitraryTest\\Shuiyang\\src\\Work4\\b.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line = "";
            while ((line = reader.readLine()) != null) {
                String upperCaseLine = line.toUpperCase();
                writer.write(upperCaseLine);
                writer.newLine();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
