package Work1;

public class StudentTest {
    public static void main(String[] args) {
        Student std1 = new Student(114514, "yhlight", 18);
        Student std2 = new Student(114515, "shuiyang", 20);
        Student std3 = new Student(114516, "huanting", 18);

        StudentManager studentManager = new StudentManager();
        studentManager.addStudent(std1);
        studentManager.addStudent(std2);
        studentManager.addStudent(std3);
        studentManager.toPrint();
        System.out.println();
        studentManager.removeStudent(std3);
        studentManager.toPrint();
        System.out.println();
        studentManager.toFindStudent("shuiyang");
    }
}