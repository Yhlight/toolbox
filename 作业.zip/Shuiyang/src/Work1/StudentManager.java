package Work1;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class StudentManager {
    private Set<Student> studentSystem = new LinkedHashSet<>();

    public StudentManager() {

    }

    public void addStudent(Student stu) {
        for (Student student : studentSystem) {
            if (student.getId() == stu.getId()) {
                System.out.println("学生ID已存在，无法重复添加");
                return;
            } else if (student.getName().equals(stu.getName())) {
                System.out.println("学生姓名已存在，无法重复添加");
                return;
            }
        }
        studentSystem.add(stu);
    }

    public void removeStudent(Student stu) {
        studentSystem.remove(stu);
    }

    public void toFindStudent(String stu) {
        for (Student std : studentSystem) {
            if (std.getName().equals(stu)) {
                System.out.println(std.getInfo());
            }
        }
    }

    public void toPrint() {
        for (Student student : studentSystem) {
            System.out.println(student);
        }
    }
}