package Work3;

import java.util.Date;
import java.util.Objects;

public class Activity {
    private int activityId;
    private String title;
    private String description;
    private Date date;
    private String location;

    public Activity() {
        activityId++;
    }

    public Activity(int activityId, String title, String description, Date date, String location) {
        this.activityId = activityId;
        this.title = title;
        this.description = description;
        this.date = date;
        this.location = location;
    }

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ID:" + activityId + " [" +
                "标题:'" + title + '\'' +
                ", 描述:'" + description + '\'' +
                ", 日期:" + date +
                ", 地点:'" + location + '\'' +
                ']';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Activity activity)) return false;
        return Objects.equals(title, activity.title) && Objects.equals(description, activity.description) && Objects.equals(date, activity.date) && Objects.equals(location, activity.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, description, date, location);
    }
}