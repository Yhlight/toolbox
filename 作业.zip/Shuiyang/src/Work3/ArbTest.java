package Work3;

import java.util.Date;

public class ArbTest {
    public static void main(String[] args) {
        Activity activity1 = new Activity(114514, "荧火光游戏开发交流会", "针对市面上一些不良游戏风气进行讨论的开发者交流会", new Date(1735954200000L), "广州番禺xxxx");
        Activity activity2 = new Activity(114516, "荧火光游戏开发交流会", "针对市面上一些不良游戏风气进行讨论的开发者交流会", new Date(1735954200000L), "广州番禺xxxx");
        ActivityManager activityManager = new ActivityManager();
        activityManager.addActivity(activity1);  //添加功能正常
        activityManager.addActivity(activity2);
        activityManager.toPrintActivity();  //遍历功能正常
        System.out.println();
        activityManager.toFindActivity("荧火光游戏开发交流会");  //查找功能正常
        System.out.println();
        activityManager.removeActivity("荧火光游戏开发交流会");  //删除功能正常
        System.out.println();
    }
}
