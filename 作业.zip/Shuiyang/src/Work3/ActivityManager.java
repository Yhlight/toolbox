package Work3;

import java.util.*;

public class ActivityManager {
    private static List<Activity> activityList = new ArrayList<>();
    private static List<Activity> removeActivityList = new ArrayList<>();
    private Activity activity;

    public ActivityManager() {
    }

    public static List<Activity> getActivityList() {
        return activityList;
    }

    public static void setActivityList(List<Activity> activityList) {
        ActivityManager.activityList = activityList;
    }

    public void addActivity(int id, String title, String description, Date date, String location) {
        activity = new Activity(id, title, description, date, location);
        activityList.add(activity);
    }

    public void addActivity(Activity activity) {
        activityList.add(activity);
    }

    public void removeActivity(String title) {
        int count = 0;
        activity = new Activity();
        for (Activity act : activityList) {
            if (act.getTitle().equals(title)) {
                count++;
                removeActivityList.add(act);
                activity = act;
            }
        }

        if (count > 1) {
            showAndDeleteActivity();
            return;
        }
        activityList.remove(activity);
    }

    public void removeActivity(Activity activity) {
        activityList.remove(activity);
    }

    public void showAndDeleteActivity() {
        boolean isFlag = true;
        Scanner scan = new Scanner(System.in);
        int count = 0;

        for (Activity act : removeActivityList) {
            System.out.println(act);
        }
        while (isFlag) {
            System.out.println("请输入数字选择删除第几项，输入0或任意负数退出");
            count = scan.nextInt();
            if (count <= 0) {
                isFlag = false;
            } else {
                activityList.remove(removeActivityList.get(count));
            }
        }
    }

    public void toPrintActivity() {
        for (Activity act : activityList) {
            System.out.println(act);
        }
    }

    public void toFindActivity(String title) {
        for (Activity act : activityList) {
            if (act.getTitle().equals(title)) {
                System.out.println(act);
            }
        }
    }

    public void toFindActivity(Activity activity) {
        for (Activity act : activityList) {
            if (act == activity) {
                System.out.println(act);
            }
        }
    }
}
