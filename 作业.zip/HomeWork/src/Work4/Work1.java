package Work4;

public class Work1 {
    public static void main(String[] args) {
        int[] arr = {234, 436, 2541, 134, 143, 231, 24, 14, 15, 2141};
        int min = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
            }
        }
        System.out.println("该数组最小值为>" + min);

        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        System.out.println("排序后的数组>");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
