package Work4;

public class Work2 {
    public static void main(String[] args) {
        Cylinder cylinder = new Cylinder(3, 5);
        System.out.println("面积: " + cylinder.area());
        System.out.println("体积: " + cylinder.volume());
    }
}

class Cylinder {
    double r, h;

    Cylinder(double r, double h) {
        this.r = r;
        this.h = h;
    }

    double area() {
        return 2 * Math.PI * r * (r + h);
    }

    double volume() {
        return Math.PI * r * r * h;
    }
}
