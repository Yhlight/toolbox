package Work4;

public class Work4 {
    public static void main(String[] args) {
        Phone phone1 = new Phone("小米", "K70", "MIUI", 3399, "16GB+1TB");
        System.out.println("手机1配置:");
        phone1.displayInfo();
        phone1.displayFeatures();
    }
}

class Phone {
    String brand;
    String model;
    String operatingSystem;
    double price;
    String memory;

    public Phone(String brand, String model, String operatingSystem, double price, String memory) {
        this.brand = brand;
        this.model = model;
        this.operatingSystem = operatingSystem;
        this.price = price;
        this.memory = memory;
    }

    public void displayInfo() {
        System.out.println("品牌: " + brand);
        System.out.println("型号: " + model);
        System.out.println("操作系统: " + operatingSystem);
        System.out.println("价格: " + price);
        System.out.println("内存: " + memory);
    }

    public void displayFeatures() {
        System.out.println("功能: 自拍, 游戏, 播放歌曲");
    }
}

