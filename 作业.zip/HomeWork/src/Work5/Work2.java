package Work5;

public class Work2 {
    public static void main(String[] args) {
        Soundable device = null;

        device = new Radio();
        device.makeSound();
        device.adjustVolume(5);

        device = new Walkman();
        device.makeSound();
        device.adjustVolume(7);

        device = new MobilePhone();
        device.makeSound();
        device.adjustVolume(10);
    }
}

interface Soundable {
    void makeSound();

    void adjustVolume(int level);
}

class Radio implements Soundable {
    public void makeSound() {
        System.out.println("收音机发声");
    }

    public void adjustVolume(int level) {
        System.out.println("收音机音量调整到：" + level);
    }
}

class Walkman implements Soundable {
    public void makeSound() {
        System.out.println("随身听发声");
    }

    public void adjustVolume(int level) {
        System.out.println("随身听音量调整到：" + level);
    }
}

class MobilePhone implements Soundable {
    public void makeSound() {
        System.out.println("手机发声");
    }

    public void adjustVolume(int level) {
        System.out.println("手机音量调整到：" + level);
    }
}