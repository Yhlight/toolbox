package Work5;

public class Work3 {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle(5, 3);
        Shape circle = new Circle(4);

        System.out.println("长方形面积：" + rectangle.getArea());
        System.out.println("长方形周长：" + rectangle.getPerimeter());

        System.out.println("圆形面积：" + circle.getArea());
        System.out.println("圆形周长：" + circle.getPerimeter());
    }
}

abstract class Shape {
    abstract double getArea();

    abstract double getPerimeter();
}

class Rectangle extends Shape {
    private double length;
    private double width;

    Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    double getArea() {
        return length * width;
    }

    double getPerimeter() {
        return 2 * (length + width);
    }
}

class Circle extends Shape {
    private double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    double getArea() {
        return Math.PI * radius * radius;
    }

    double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}