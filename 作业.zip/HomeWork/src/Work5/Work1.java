package Work5;

public class Work1 {
    public static void main(String[] args) {
        Feeder feeder = new Feeder();
        Dog dog = new Dog();
        Cat cat = new Cat();

        feeder.feed(dog);
        feeder.feed(cat);
    }
}

abstract class Animal {
    abstract void makeSound();
}

class Dog extends Animal {
    void makeSound() {
        System.out.println("汪汪");
    }
}

class Cat extends Animal {
    void makeSound() {
        System.out.println("喵喵");
    }
}

class Feeder {
    void feed(Animal animal) {
        animal.makeSound();
    }
}
