package Work2;

import org.junit.jupiter.api.Test;

import java.util.Scanner;

public class Work1 {
    @Test
    public void test1() {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();

        if (num % 3 == 0 && num % 5 == 0) {
            System.out.println("Yes");
        } else {
            System.out.println("NO");
        }
    }
}
