package Work2;

import org.junit.jupiter.api.Test;

import java.util.Scanner;

public class Work2 {
    @Test
    public void test() {
        Scanner scan = new Scanner(System.in);
        int pm = scan.nextInt();

        if (pm > 0 && pm < 35) {
            System.out.println("优");
        } else if (pm >= 35 && pm < 75) {
            System.out.println("良好");
        } else if (pm >= 75) {
            System.out.println("差");
        } else {
            System.out.println("输入错误");
        }
    }
}
