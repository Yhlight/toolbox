package Work2;

import org.junit.jupiter.api.Test;

import java.util.Scanner;

public class Work3 {
    @Test
    public void test() {
        Scanner scan = new Scanner(System.in);
        int num1 = scan.nextInt();
        int num2 = 0;

        if (num1 < 5) {
            num2 = 0;
        } else if (num1 >= 5 && num1 < 10) {
            num2 = 5 * num1 - 25;
        } else {
            num2 = (num1 - 5) * (num1 - 5);
        }
        System.out.println(num2);
    }
}
