package Work2;

import org.junit.jupiter.api.Test;

public class Work7 {
    @Test
    public void test() {
        for (int x = 0; x <= 100; x++) {
            for (int y = 0; y <= 100; y++) {
                int z = 100 - x - y;
                if (z >= 0 && 3 * x + 2 * y + 0.5 * z == 100) {
                    System.out.println("大马: " + x + "匹, 中马: " + y + "匹, 小马: " + z + "匹");
                }
            }
        }

    }
}
