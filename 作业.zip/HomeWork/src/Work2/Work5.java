package Work2;

import org.junit.jupiter.api.Test;

public class Work5 {
    @Test
    public void test() {
        for (int i = 1; i <= 10000; i++) {
            if (isPerfect(i)) {
                System.out.println(i);
            }
        }
    }

    public static boolean isPerfect(int number) {
        int sum = 0;
        for (int i = 1; i <= number / 2; i++) {
            if (number % i == 0) {
                sum += i;
            }
        }
        return sum == number;
    }
}
