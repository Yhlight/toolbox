package Work1;

import org.junit.jupiter.api.Test;

public class Work1 {
    @Test
    public void test() {
        Phone xiaoMi = new Phone("REDMI Turbo 4", 2499, "16GB+512GB" + "100", 100);
        System.out.println("当前仓库中拥有的小米手机总价值为>" + xiaoMi.getTotalPrice());
    }
}

class Phone {
    private String name;
    private double price;
    private String configuration;
    private double inventory;

    public Phone(String name, double price, String configuration, double inventory) {
        this.name = name;
        this.price = price;
        this.configuration = configuration;
        this.inventory = inventory;
    }

    public Phone() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getConfiguration() {
        return configuration;
    }

    public void setConfiguration(String configuration) {
        this.configuration = configuration;
    }

    public double getInventory() {
        return inventory;
    }

    public void setInventory(double inventory) {
        this.inventory = inventory;
    }

    public double getTotalPrice() {
        return price * inventory;
    }
}