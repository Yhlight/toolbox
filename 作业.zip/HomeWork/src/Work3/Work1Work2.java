package Work3;

import java.util.*;

public class Work1Work2 {
    public static void main(String[] args) {
        Shop shop = new Shop();
        shop.toShow();
        shop.shopping(20);
    }
}

class Shop {
    private Map<String, Double> shopItems = new LinkedHashMap<>();

    {
        shopItems.put("书本", 12.0);
        shopItems.put("铅笔", 1.0);
        shopItems.put("橡皮", 2.0);
        shopItems.put("可乐", 3.0);
        shopItems.put("零食", 5.0);
    }

    public void toShow() {
        System.out.println(shopItems);
    }

    public void shopping(double money) {
        money = money - shopItems.get("书本");
        String items = " ";
        Scanner scan = new Scanner(System.in);
        Map<String, Integer> shopPingItems = new LinkedHashMap<>();

        double minPrice = Collections.min(shopItems.values());

        while (money >= minPrice || items.equals("0")) {
            System.out.print("请选择你需要购买的物品>(输入0结束购买)");
            items = scan.nextLine();
            if (shopItems.containsKey(items)) {
                if (shopItems.get(items) <= money) {
                    System.out.println("购买成功");
                    money -= shopItems.get(items);
                    System.out.println("你还有" + money + "元");
                    shopPingItems.put(items, shopPingItems.getOrDefault(items, 0) + 1);
                } else {
                    System.out.println("你的钱不够购买此商品");
                }
            } else {
                System.out.println("没有此商品");
            }
        }

        System.out.println("你购买的商品如下：");
        for (Map.Entry<String, Integer> entry : shopPingItems.entrySet()) {
            System.out.println(entry.getKey() + " x " + entry.getValue());
        }
    }
}
