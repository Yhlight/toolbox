package Work3;

import java.util.Scanner;

public class Work5 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("请输入员工姓名：");
        String name = scanner.nextLine();

        System.out.print("请输入应聘语言：");
        String language = scanner.nextLine();

        String department = getDepartment(language);

        if (department != null) {
            System.out.println(name + " 被分配到 " + department + " 部门。");
        } else {
            System.out.println("公司没有与输入的语言相匹配的部门。");
        }
    }

    public static String getDepartment(String language) {
        switch (language) {
            case "java":
                return "Java 程序开发";
            case "c#":
                return "C# 程序开发";
            case "asp.net":
                return "asp.net 程序测试";
            case "前端":
                return "前端程序开发";
            default:
                return null;
        }
    }
}