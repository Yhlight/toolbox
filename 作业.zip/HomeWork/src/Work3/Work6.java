package Work3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Work6 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> audience = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            System.out.print("请输入第" + (i + 1) + "名观众的姓名：");
            String name = scanner.nextLine();
            audience.add(name);
        }

        System.out.println("观众名单：");
        for (String name : audience) {
            System.out.println(name);
        }

        Random random = new Random();
        int luckyIndex = random.nextInt(audience.size());
        System.out.println("幸运观众是：" + audience.get(luckyIndex));
    }
}
