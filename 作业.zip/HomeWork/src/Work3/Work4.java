package Work3;

import java.util.Random;
import java.util.Scanner;

public class Work4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        String[] options = {"剪刀", "石头", "布"};
        int playerWins = 0;
        int computerWins = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("请输入你的选择（剪刀、石头、布）：");
            String playerChoice = scanner.nextLine();
            int computerChoice = random.nextInt(3);
            System.out.println("电脑选择了：" + options[computerChoice]);

            if (playerChoice.equals(options[computerChoice])) {
                System.out.println("这一轮是平局！");
            } else if ((playerChoice.equals("剪刀") && options[computerChoice].equals("布")) ||
                    (playerChoice.equals("石头") && options[computerChoice].equals("剪刀")) ||
                    (playerChoice.equals("布") && options[computerChoice].equals("石头"))) {
                System.out.println("你赢了这一轮！");
                playerWins++;
            } else {
                System.out.println("电脑赢了这一轮！");
                computerWins++;
            }
        }

        System.out.println("游戏结束！");
        if (playerWins > computerWins) {
            System.out.println("你赢了游戏！");
        } else if (computerWins > playerWins) {
            System.out.println("电脑赢了游戏！");
        } else {
            System.out.println("游戏是平局！");
        }
    }
}
