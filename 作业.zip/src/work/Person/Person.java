package work.Person;

public class Person {
    protected String name;
    protected int age;

    public void eat() {
        System.out.println("人吃饭");
    }

    public void walk() {
        System.out.println("人走路");
    }
}