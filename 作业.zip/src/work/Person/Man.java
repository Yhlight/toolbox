package work.Person;

public class Man extends Person {
    boolean isSmoke;

    public void eat() {
        System.out.println("男人多吃饭");
    }

    public void walk() {
        System.out.println("男人应该多走路");
    }

    public void earn() {
        System.out.println("男人要挣钱养家");
    }

}