package work.Person;

public class Woman extends Person {
    boolean isBeauty;

    public void eat() {
        System.out.println("要控制分量");
    }

    public void walk() {
        System.out.println("女人要多走路");
    }

    public void goShopping() {
        System.out.println("逛街");
    }

}
