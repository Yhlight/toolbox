package work.Person;

public class PersonTest {
    public static void main(String[] args) {
        PersonTest personTest = new PersonTest();
        Man man = new Man();
        man.eat();
    }
}
