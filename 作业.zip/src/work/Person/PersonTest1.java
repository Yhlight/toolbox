package work.Person;

public class PersonTest1 {
    public static void main(String[] args) {
        Person p1 = new Man();
        //p1.earn();  对不起，做不到
        Man m1 = (Man) p1;
        m1.earn();

        //类型转换异常，编译器不报错
        //运行会报错
        //我们建议在使用向下转型之前使用instanceof进行判断
        Person p2 = new Woman();
        if(p2 instanceof Man) {
            Man m2 = (Man) p2;
            m2.isSmoke=true;
        }
    }
}
