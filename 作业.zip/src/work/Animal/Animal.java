package work.Animal;

public abstract class Animal {
    public abstract void makeSound();
}