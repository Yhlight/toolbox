package work.Animal;

public class Dolphin extends Animal {

    public void makeSound() {
        System.out.println("海豚叫");
    }
}
