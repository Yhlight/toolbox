package work.Animal;

public class Lion extends Animal {
    public void makeSound() {
        System.out.println("狮子叫");
    }
}
