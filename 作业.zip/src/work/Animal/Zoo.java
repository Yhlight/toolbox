package work.Animal;

public class Zoo {
    private Animal[] list;
    private int count;

    public Zoo(int count) {
        list = new Animal[count];
    }

    public void addAnimal(Animal animal) {
        list[count] = animal;
        count++;
    }

    public void displaySounds() {
        for (int i = 0; i < count; i++) {
            list[i].makeSound();
        }
    }
}
