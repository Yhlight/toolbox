package work.Task;

public class AccountTest {
    public static void main(String[] args) {
        Account account = new Account();
        account.setAccount("张三");

        account.setPassword("11111111111111111111");
        account.setPassword("2222");
        account.setPassword("3333");
        account.toPrintAccount();
        account.toPrintPassword();
    }
}

class Account {
    private String[] account;
    private String[] password;
    private int count;
    private int passwordCount;

    Account() {
        account = new String[20];
        account[0] = "Administrator";
        password = new String[20];
        password[0] = "01100110";
        count = 1;
        passwordCount = 1;
    }

    public void setAccount(String str) {
        if (count < 20 && count > 0) {
            account[count] = str;
            count++;
        }
    }

    public void setPassword(String str) {
        if (passwordCount < 20 && passwordCount > 0) {
            password[passwordCount] = str;
            passwordCount++;
        }
    }

    public void toPrintAccount() {
        System.out.print("[");

        for (int i = 1; i < account.length; i++) {
            if (i == 1 && account[i] != null) {
                System.out.print(account[i]);
            } else {
                if (account[i] == null) {
                    break;
                }
                System.out.print("," + account[i]);
            }
        }
        System.out.println("]");
    }

    public void toPrintPassword() {
        System.out.print("[");

        for (int i = 1; i < password.length; i++) {
            if (i == 1 && password[i] != null) {
                System.out.print(password[i]);
            } else {
                if (password[i] == null) {
                    break;
                }
                System.out.print("," + password[i]);
            }
        }
        System.out.println("]");
    }


    public void toPrint(int[] arr1, int[] arr2) {
        System.out.print("[");

        for (int i = 0; i < arr1.length; i++) {
            if (i == 0) {
                System.out.print(arr1[i]);
            } else {
                System.out.print("," + arr1[i]);
            }
        }
        System.out.println("]");
    }
}