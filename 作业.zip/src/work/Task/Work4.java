package work.Task;

import java.util.Scanner;

public class Work4 {
    public static void main(String[] args) {
        int line = 0;
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入等腰三角形行数>");
        line = scan.nextInt();

        for (int i = 0; i < line; i++) {

            for (int k = 0; k < line - i - 1; k++) {
                System.out.print(" ");
            }

            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        scan.close();
    }
}
