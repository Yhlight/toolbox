package work.Task;

import java.util.Scanner;

public class Work3 {
    public static void main(String[] args) {
        int x = 0;
        int y = 0;
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入x的值>");
        x = scan.nextInt();

        if (x > 0 && x < 5) {
            y = 0;
        } else if (x >= 5 && x < 10) {
            y = 5 * x - 25;
        } else {
            y = (x - 5) * (x - 5);
        }
        System.out.println(y);
        scan.close();
    }
}
