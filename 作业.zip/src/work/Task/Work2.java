package work.Task;

import java.util.Scanner;

public class Work2 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入PM2.5值>");
        int num = scan.nextInt();
        if (num >= 0 && num < 35) {
            System.out.println("优");
        } else if (num >= 35 && num < 75) {
            System.out.println("良");
        } else {
            System.out.println("污染");
        }
        scan.close();
    }
}
