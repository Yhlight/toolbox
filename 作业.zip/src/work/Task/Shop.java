package work.Task;

import java.util.Scanner;

public class Shop {
    public static void main(String[] args) {
        double book = 12;
        double pencil = 1;
        double rubber = 2;
        double coke = 3;
        double food = 5;
        double money = 20;
        int count = 0;
        double good = 0;
        String goodName = "";
        boolean isExit = true;
        Scanner scan = new Scanner(System.in);

        //应该封装成方法
        do {
            System.out.println("******欢迎光临******");
            System.out.println("******************");
            System.out.println("书本 12元    铅笔 1元");
            System.out.println("橡皮  2元    可乐 3元");
            System.out.println("食物  5元");
            System.out.println("******************");
            System.out.print("请输入相应商品以进行购买>");
            goodName = scan.next();
            //可以设置一个方法获取价格
            switch (goodName) {
                case "书本":
                    good = book;
                    break;
                case "铅笔":
                    good = pencil;
                    break;
                case "橡皮":
                    good = rubber;
                    break;
                case "可乐":
                    good = coke;
                    break;
                case "食物":
                    good = food;
                    break;
                default:
                    System.out.println("输入错误");
                    continue;
            }
            isExit = false;
        } while (isExit);

        money -= book;
        while (true) {
            if (money >= good) {
                count++;
                money -= good;
            } else {
                System.out.println("不够钱买");
                //预留一个地方，方便加入方法返回选择购买
                break;
            }
        }

        System.out.println("可以购买" + count + "个" + goodName + " 剩余" + money + "元");
        scan.close();
    }
}
