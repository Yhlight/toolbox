package work.Task;

import java.util.Scanner;

public class Work6 {
    public static void main(String[] args) {
        int x = 0;
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入乘法表最大数字>");
        x = scan.nextInt();

        for (int i = 1; i <= x; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + " * " + i + " = " + (i * j) + "\t");
            }
            System.out.println();
        }
        scan.close();
    }
}
