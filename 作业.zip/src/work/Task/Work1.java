package work.Task;

import java.util.Scanner;

public class Work1 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入数字>");
        int num = scan.nextInt();
        if (num % 5 == 0 && num % 3 == 0) {
            System.out.println("yes");
        } else {
            System.out.println("no");
        }
        scan.close();
    }
}