package work.Exer;

interface CompareObject {
    public abstract int compareTo(Object o);
}
