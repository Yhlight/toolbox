package work.Vehicle;

public class Develop {
    private String brand;
    private int age;

    public Develop() {

    }

    public Develop(String brand, int age) {
        this.brand = brand;
        this.age = age;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void takingVehicle(Vehicle vehicle) {
        vehicle.run();
    }
}
