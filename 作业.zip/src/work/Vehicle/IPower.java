package work.Vehicle;

public interface IPower {
    public abstract void power();
}
