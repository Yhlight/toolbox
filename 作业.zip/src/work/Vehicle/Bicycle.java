package work.Vehicle;

public class Bicycle extends Vehicle {
    public Bicycle() {

    }

    public Bicycle(String brand, String color) {
        super(brand, color);
    }

    public void run() {
        System.out.println("自行车人力运行");
    }

}
