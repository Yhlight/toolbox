package work.Vehicle;

public class VehicleTest {
    public static void main(String[] args) {
        Develop develop = new Develop();

        Vehicle[] vehicles = new Vehicle[3];
        vehicles[0] = new Bicycle("1145", "红色");
        vehicles[1] = new ElectricVehicle("2345", "黑色");
        vehicles[2] = new Car("11451419810");

        develop.takingVehicle(vehicles[0]);
        develop.takingVehicle(vehicles[1]);
        develop.takingVehicle(vehicles[2]);
    }
}
