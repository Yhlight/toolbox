package work.User;

public class UserTest {
    public static void main(String[] args) {
        User user1 = new User();
        System.out.println(user1.getInfo());

        User user2 = new User("yinghuolight","1145145");
        System.out.println(user2.getInfo());
    }
}
