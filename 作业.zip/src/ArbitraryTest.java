import org.junit.jupiter.api.Test;

import java.util.*;

public class ArbitraryTest {
    @Test
    public void test1() {
        List list = new ArrayList();
        list.add("String");  //添加元素
        list.add(114514);
        list.add(1.001);
        System.out.println(list.size());  //集合的元素个数
        System.out.println(list);

        //增强for循环
        for (Object obj : list) {
            System.out.println(obj);
        }

        list.remove(2);  //删除下标为2的集合元素，即第三个
        System.out.println(list);
        System.out.println(list.get(1)); //获取下标为2的集合元素
        System.out.println(list.contains(114514));  //集合中是否包含这个元素
        System.out.println();
        list.clear();  //清空列表
        System.out.println(list);
    }

    @Test
    public void test2() {
        List<String> list = new ArrayList<>();  //泛型的使用
    }
}