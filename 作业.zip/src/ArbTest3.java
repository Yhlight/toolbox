import org.junit.jupiter.api.Test;

public class ArbTest3 {
    @Test
    public void test() {
        YhLight[] yhLights = new YhLight[3];
        yhLights[0] = new YhLight("yhlight");
        yhLights[1] = new YhLight("yhlight");
        yhLights[2] = new YhLight("shuiyang");
        System.out.println(yhLights[0].equals(yhLights[1]));
    }

    class YhLight {
        private String name;

        public YhLight(String name) {
            this.name = name;
        }

        public YhLight() {
        }

        @Override
        public String toString() {
            return "YhLight{" +
                    "name='" + name + '\'' +
                    '}';
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }

            if (o instanceof YhLight) {
                YhLight yhLight = (YhLight) o;
                return this.name.equals(yhLight.name);
            }
            throw new RuntimeException();
        }
    }
}
