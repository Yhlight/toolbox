package com.yinghuolight.Math;

public class Test {
    public static void main(String[] args) {
        GeometricObject g1 = new Cylinder("圆柱体", 1.0, 2, 4);
        GeometricObject g2 = new MyRectangle("长方形", 1.0, 2, 4);
        System.out.println(MathUtil.equalsArea(g1, g2));
        MathUtil.displayGeometricObjectArea(g1);
        MathUtil.displayGeometricObjectArea(g2);
        System.out.println(MathUtil.getSum(5, 5, 5, 5));
        System.out.println(MathUtil.getAverage(5, 5, 5, 5));
    }
}