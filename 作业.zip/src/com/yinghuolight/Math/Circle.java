package com.yinghuolight.Math;

public class Circle extends GeometricObject {
    protected double radius;

    public Circle() {

    }

    public Circle(String color, double weight, double radius) {
        super(color, weight);
        this.radius = radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public double findArea() {
        return 3.14 * radius * radius;
    }
}
