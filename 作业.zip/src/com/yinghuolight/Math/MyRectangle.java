package com.yinghuolight.Math;

public class MyRectangle extends GeometricObject {
    private double width;
    private double heigth;

    public MyRectangle() {
    }

    public MyRectangle(String color, double weight, double width, double heigth) {
        super(color, weight);
        this.width = width;
        this.heigth = heigth;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeigth() {
        return heigth;
    }

    public void setHeigth(double heigth) {
        this.heigth = heigth;
    }

    public double findArea() {
        return width * heigth;
    }
}
