package com.yinghuolight.Math;

public class Cylinder extends Circle {
    private double length;

    public Cylinder() {

    }

    public Cylinder(String color, double weight, double radius, double length) {
        super(color, weight, radius);
        this.length = length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getLength() {
        return length;
    }

    public double findArea() {
        return 2 * 3.14 * radius * radius + 2 * 3.14 * radius * length;
    }

    public double findVolume() {
        return 3.14 * super.findArea() * getLength();
    }
}
