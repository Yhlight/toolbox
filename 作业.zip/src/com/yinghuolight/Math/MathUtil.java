package com.yinghuolight.Math;

public class MathUtil {
    /**
     * 任意数量变量求和
     * @return 多个变量总和
     */
    public static int getSum(int... arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }

    /**
     * 任意数量变量求和
     * @param arr
     * @return 多个变量的平均值
     */
    public static int getAverage(int... arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum/arr.length;
    }

    /**
     * 比较两个几何图形的面积是否相等
     *
     * @param g1
     * @param g2
     * @return true or false
     */
    public static boolean equalsArea(GeometricObject g1, GeometricObject g2) {
        return g1.findArea() == g2.findArea();
    }

    /**
     * 显示几何图形的面积
     *
     * @param g
     */
    public static void displayGeometricObjectArea(GeometricObject g) {
        System.out.println(g.findArea());
    }
}
