package com.yinghuolight.arrays;

public class MyArrays {

    /**
     * 获取int[]数组的最大值
     *
     * @param arr 要获取最大值的数组
     * @return 数组的最大值
     */
    public static int getMax(int[] arr) {
        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (max < arr[i]) {
                max = arr[i];
            }
        }
        return max;
    }

    /**
     * 获取int[]数组的最小值
     *
     * @param arr 要获取最小值的数组
     * @return 数组的最小值
     */
    public static int getMin(int[] arr) {
        int min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
            }
        }
        return min;
    }

    /**
     * 获取int[]数组的元素总和
     *
     * @param arr 要获取元素总和的数组
     * @return 数组的元素总和
     */
    public static int getSum(int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }

    /**
     * 获取int[]数组的元素平均值
     *
     * @param arr 要获取元素平均值的数组
     * @return 数组的元素平均值
     */
    public static int getAvg(int[] arr) {
        return getSum(arr) / arr.length;
    }

    /**
     * 打印int[]数组
     *
     * @param arr 要打印的数组
     */
    public static void toPrint(int[] arr) {
        System.out.print("[");

        for (int i = 0; i < arr.length; i++) {
            if (i == 0) {
                System.out.print(arr[i]);
            } else {
                System.out.print("," + arr[i]);
            }

        }

        System.out.println("]");
    }

    /**
     * 遍历arr数组
     *
     * @param arr 要打印的数组
     * @return 字符串形式的arr数组
     */
    public static String print(int[] arr) {
        String str = "[";

        for (int i = 0; i < arr.length; i++) {
            if (i == 0) {
                str += arr[i];
            } else {
                str += "," + arr[i];
            }
        }

        str += "]";
        return str;
    }

    /**
     * 复制数组
     *
     * @param arr 要复制的数组
     * @return 一模一样的数组
     */
    public static int[] copy(int[] arr) {
        int[] newArr = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            newArr[i] = arr[i];
        }
        return newArr;
    }

    /**
     * 数组的逆序
     *
     * @param arr 要逆序的数组
     */
    public static void reverse(int[] arr) {
        for (int i = 0, j = arr.length - 1; i < j; i++, j--) {
            int tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
    }

    /**
     * 数组的排序
     *
     * @param arr 要排序的数组
     */
    public static void sort(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                }
            }
        }
    }

    public static void sort(int[] arr, int[] arr2) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                }
            }
        }
    }

    /**
     * 线性查找
     *
     * @param arr 要查找的数组
     * @return 所要查找的数字的索引，若未找到，返回-1
     */
    public static String linearSearch(int[] arr, int searchInt) {
        boolean found = false;
        String output = "存在数字" + searchInt + " 索引为>";

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == searchInt) {
                if (found) {
                    output += ",";
                }
                output += i;
                found = true;
            }
        }

        if (!found) {
            output = "不存在数字" + searchInt;
        }

        return output;
    }
}
