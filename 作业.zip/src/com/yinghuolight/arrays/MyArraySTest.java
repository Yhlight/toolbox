package com.yinghuolight.arrays;

import java.util.Arrays;

public class MyArraySTest {
    public static void main(String[] args) {
        int[] arr = new int[]{34, 56, 223, 2, 56, 24, 33, 67, 778, 45};
        int max = MyArrays.getMax(arr);
        System.out.println(max);

        int min = MyArrays.getMin(arr);
        System.out.println(min);

        int sum = MyArrays.getSum(arr);
        System.out.println(sum);

        int avg = MyArrays.getAvg(arr);
        System.out.println(avg);

        MyArrays.print(arr);

        int[] newArr = MyArrays.copy(arr);
        MyArrays.print(newArr);

        MyArrays.reverse(arr);
        MyArrays.print(arr);

        MyArrays.sort(arr);
        Arrays.sort(arr);
        MyArrays.print(arr);

        String search = MyArrays.linearSearch(arr, 56);
        System.out.println(search);
    }
}
