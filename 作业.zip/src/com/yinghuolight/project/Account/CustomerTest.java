package com.yinghuolight.project.Account;

public class CustomerTest {
    public static void main(String[] args) {
        Customer customer = new Customer();
        Accounts accounts = new Accounts(114514, 20000, 0.045);
        customer.setName("yinghuolight");
        customer.setAccounts(accounts);
        customer.getAccounts().deposit(3000);
        customer.getAccounts().withdraw(5500);

        System.out.println();
        System.out.println(customer.getAccounts().getId() + "用户" + customer.getName() + "的账户现持有>" + customer.getAccounts().getBalance() + "余额");
    }
}
