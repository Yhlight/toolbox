package com.yinghuolight.project.Account;

public class Customer {
    private String name;
    private Accounts accounts;

    public Customer() {

    }

    public Customer(String name, Accounts accounts) {
        this.name = name;
        this.accounts = accounts;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAccounts(Accounts accounts) {
        this.accounts = accounts;
    }

    public Accounts getAccounts() {
        return accounts;
    }

}
