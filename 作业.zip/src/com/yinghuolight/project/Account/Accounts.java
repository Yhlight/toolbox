package com.yinghuolight.project.Account;

public class Accounts {
    private int id;
    private double balance;
    private double annuallnterestRate;

    public Accounts() {

    }

    public Accounts(int id, double balance, double annuallnterestRate) {
        this.id = id;
        this.balance = balance;
        this.annuallnterestRate = annuallnterestRate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAnnuallnterestRate() {
        return annuallnterestRate;
    }

    public void setAnnuallnterestRate(double annuallnterestRate) {
        this.annuallnterestRate = annuallnterestRate;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getMonthlyInterest() {
        return annuallnterestRate / 12;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("已存入金额" + amount + "，" + "账户余额为>" + balance);
        } else {
            System.out.println("输入错误，请重新输入");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("已取出金额" + amount + "，" + "账户余额为>" + balance);
        } else {
            System.out.println("输入错误，请重新输入，请检查是否账户余额是否足够或者输入是否有误");
        }
    }
}
