package com.yinghuolight.project.Account;

public class CheckAccountTest {
    public static void main(String[] args) {
        CheckAccount checkAccount = new CheckAccount(114514,20000,0.045,5000);
        checkAccount.withdraw(5000);
        System.out.println("您的可透支额>" + checkAccount.getoverdraft());

        checkAccount.withdraw(18000);
        System.out.println("您的可透支额>" + checkAccount.getoverdraft());
    }
}
