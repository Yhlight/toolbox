package com.wojianzhu.lover;

public class JianZhu {
    private String name;
    private String loverSay;

    public JianZhu() {
        name = "我见竹";
        loverSay = "关注见竹老师谢谢喵";
    }

    public void loverSay(String loverSay) {
        this.loverSay = loverSay;
    }

    public String toPrint() {
        return loverSay;
    }
}
